CP210x Macintosh OSX Driver v1.00 Release Notes
Copyright (C) 2004 Silicon Laboratories, Inc.

This release contains the following components:

* cardinal-osx-V1_00e-release.zip
* Readme.txt (this file)


Known Issues and Limitations
----------------------------

	This release includes the MacIntosh OSX driver.
	
	This release does not include the MacIntosh OS9 driver. 
	It is available by request from the factory.  


Driver Installation
-------------------

	See Evaluation Kit User's Guide for installation instructions.


CP210x Macintosh OSX Driver Revision History
--------------------------------------------

Version 1.00

	Initial Release


