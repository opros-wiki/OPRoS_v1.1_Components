CP210x Linux Driver v0.81b Release Notes
Copyright (C) 2004 Silicon Laboratories, Inc.

This release contains the following components:

* cardinal-redhat9-V0_81b.tar.gz
* Readme.txt (this file)


Known Issues and Limitations
----------------------------

	This release includes drivers for Linux v2.4 and greater.
	

Driver Installation
-------------------

	See Evaluation Kit User's Guide for installation instructions.


CP210x Linux Driver Revision History
--------------------------------------

Version 0.81b

	This version fixes an issue which caused a machine crash when 
	disconnecting from a modem.

Version 0.81

	Initial Release


